package Week04;

public class Student {

}
