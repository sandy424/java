package Week04;

public class Car {
	String model;
	boolean start;
	int speed;
}
